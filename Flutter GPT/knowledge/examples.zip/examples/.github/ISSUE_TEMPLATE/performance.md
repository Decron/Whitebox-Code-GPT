---
name: Performance Update
about: A code change that improves performance
title: "perf: "
labels: performance
---

**Description**

Clearly describe what code needs to be changed and what the performance impact is going to be.
