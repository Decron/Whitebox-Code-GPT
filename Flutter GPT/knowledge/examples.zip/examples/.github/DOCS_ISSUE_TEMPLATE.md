---
title: "[Translations] Update docs"
labels: documentation, translation
---
Update Translations to include changes from {{ sha }}.

- [ ] az (@KenanYusubov)
- [ ] cs
- [ ] es (@KingDarBoja or @Classy-Bear)
- [ ] fr (@sachaarbonel or @StefanYYC)
- [ ] jp (@dshukertjr)
- [ ] ko-kr (@zoomKoding)
- [ ] pt-br (@rodrigobastosv or @alisson-suzigan)
- [ ] ru (@basilex)
- [ ] zh-cn (@jakecastelli)
