export 'view/splash_page.dart';
