import 'package:flutter/material.dart';
import 'package:flutter_timer/app.dart';

void main() => runApp(const App());
