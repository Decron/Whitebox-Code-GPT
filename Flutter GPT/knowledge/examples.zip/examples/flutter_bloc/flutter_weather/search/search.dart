export 'view/search_page.dart';
